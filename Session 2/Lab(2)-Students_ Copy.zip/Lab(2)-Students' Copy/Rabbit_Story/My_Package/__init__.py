from My_Package.Rabbit import *
from My_Package.Animals import *
from My_Package.Questions_Answers import *
from My_Package.Mother_Rabbit import *

# Dog Object
MyDog_Questions = [QuestionsAnswers("Jump 100 times ",100,"Done"),
                   QuestionsAnswers("Can you Say this list without repeats ['Duck', 'Giraffe', 'Elephant', 'Elephant', 'Duck']",['Duck', 'Giraffe', 'Elephant', 'Elephant', 'Duck'],set(['Elephant', 'Giraffe', 'Duck']))]
# TODO:Create Dog Object

# Cat Object
MyCat_Words = "Twinkle Twinkle Little Star, How I wonder what you are, Up above the world so high Like a diamond in the sky"
MyCat_Questions = [QuestionsAnswers("Tell Rabbit what is the last 7 chracters in my song ",MyCat_Words,"the sky"),
                   QuestionsAnswers("Tell Me Rabbit is the Word Up is in my song ",MyCat_Words,"yes"),
                   QuestionsAnswers("Tell Me Rabbit is the length of my song ",MyCat_Words,108)]
MyCat = Animal("Cat", "Poussy", MyCat_Words,MyCat_Questions,3)

# Fox Object
MyFox_Words = "I am The Malicious Fox HAHAHAHA"
MyFox_Questions = [QuestionsAnswers("Calculate Square Root ?! ",64,8),
                   QuestionsAnswers("Sort the following list [1,2,0,4]",[1,2,0,4],[4,2,1,0]),
                   QuestionsAnswers("Say I am Hungry 3 times","I am Hungry","I am HungryI am HungryI am Hungry"),
                   QuestionsAnswers("Calculates 4 factorial",6,720)]
MyFox = Animal("Fox", "Foxie", MyFox_Words, MyFox_Questions,7)

# Monkey Object
MyMonkey_Words = "I am the smartest animal ever"
MyMonkey_Questions = [QuestionsAnswers("Calculate The Matrix * 2 ",[[2,3],[1,2],[6,6]],[[4,6],[2,4],[12,12]]),
                      QuestionsAnswers("Tell Me Rabbit the max , min , avg of this list [1,2,3,4,5]",[1,2,3,4,5],[5,1,3,15])]
MyMonkey = Animal("Monkey", "MicKo", MyMonkey_Words,MyMonkey_Questions,7)

# Lion Object
MyLion_Words = "I am the king hahahaha"
MyLion_Questions = [QuestionsAnswers("Tell Rabbit What 's your name ? ","Name","Bunny"),
                    QuestionsAnswers("Tell Rabbit What 's your color ? ","Color","White"),
                    QuestionsAnswers("Tell Rabbit Where are you from ? ","Forest","NeverLand")]
MyLion = Animal("Lion", "LoLoKing", MyLion_Words.upper(),MyLion_Questions,3)

# Mothet Rabbit
Mom = MotherRabbit("Mummy")

# Rabbit Object
Rabbit_Words = "I am Hungry, Please Give me Food"
Rabbit_Dictionary = {'Age': '7', 'Name': 'Bunny', 'Color': 'White', 'Eyes': 'Blue'}
MyRabbit = Rabbit("Bunny", Rabbit_Words, Rabbit_Dictionary , Mom)

# ================================================== Story Starts From Here =====================================================
                          #Rabbit talks with Mom
MyRabbit.Talk_Mother()
MyRabbit.move_step()
print("           ####  Bunny is walking alone in the Forest  ####")
print("           ####  Bunny finds a cat playing with a ball ####")
                        #Rabbit plays with cat
MyRabbit.talk_animal(MyCat)
Rabbit_Score = MyRabbit.answer_animals_questions(MyCat)
if Rabbit_Score == MyCat.score:
    print("Cat : Bravoooooo I will give you some fish")
else:
    print ("Cat : Sorrrry No Food ")
print("Bunny : Ohh Noo I am Leaving")
MyRabbit.move_step()
                       # Rabbit plays with Dog
print("           ####  Bunny is walking alone in the Forest  ####")
print("           ####  Bunny finds a Dog playing with a butterfly ####")
MyRabbit.talk_animal(MyDog)
Rabbit_Score = MyRabbit.answer_animals_questions(MyDog)
if Rabbit_Score == MyDog.score:
    print("Dog : Bravoooooo I will give you some Bones")
else:
    print ("Dog : Sorrrry No Food ")
print("Bunny : Ohh Noo It's too hard to my teeth I don't like it, I am Leaving")
MyRabbit.move_step()
                       # Rabbit plays with Monkey
print("           ####  Bunny is walking alone in the Forest  ####")
print("           ####  Bunny finds a Monkey playing on the tree ####")
MyRabbit.talk_animal(MyMonkey)
Rabbit_Score = MyRabbit.answer_animals_questions(MyMonkey)
if Rabbit_Score == MyMonkey.score:
    print("Monkey : Bravoooooo I will give you  Banana")
else:
    print ("Monkey : Sorrrry No Food ")
print("Bunny : Ohh Noo I am Leaving")
                       # Rabbit plays with Fox
MyRabbit.move_step()
print("           ####  Bunny is walking alone in the Forest  ####")
print("           ####  Bunny finds a Fox having a nape ####")
MyRabbit.talk_animal(MyFox)
Rabbit_Score = MyRabbit.answer_animals_questions(MyFox)
if Rabbit_Score == MyFox.score:
    print("Fox : Bravoooooo I will give you fish")
else:
    print ("Fox : Sorrrry No Food ")
print("Bunny : Ohh Noo I am Leaving")
                       # Rabbit plays with Lion
MyRabbit.move_step()
print("           ####  Bunny is walking alone in the Forest  ####")
print("           ####  Bunny finds a Lion roaring ####")
MyRabbit.talk_animal(MyLion)
Rabbit_Score = MyRabbit.answer_animals_questions(MyLion)
if Rabbit_Score == MyLion.score:
    print("Lion : Bravoooooo I will give you fish")
else:
    print ("Lion : I will eat You ")
print("Bunny : Ohh Noo I am going home ")

exit()
