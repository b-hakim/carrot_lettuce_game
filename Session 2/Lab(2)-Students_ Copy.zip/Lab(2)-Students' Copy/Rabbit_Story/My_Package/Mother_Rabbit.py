class MotherRabbit:

    Food = "10 Carrots and 10 Lettuce"
    Greeting = "Good Morning Bun"

    def __init__(self, name):
        self.Name = name

    @classmethod
    def cook(cls):
        print("Mother : I am Cooking %s " %(MotherRabbit.Food))

    @classmethod
    def say_greeting(cls):
        print ("Mother : " + MotherRabbit.Greeting)