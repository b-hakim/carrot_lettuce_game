class Animal:

    #Todo: Write Constructor

    def say_words(self):
        print(self.Animal_Type+ " : "+self.Animal_Words)
        print(self.Animal_Type + " : " + "Ok First Answer My Question")
