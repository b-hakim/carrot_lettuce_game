import math

class Rabbit:

    Greeting = "Bunny: Good Morning Mom! Are we gonna eat carrots and lettuce again"

    def __init__(self, name, rabbit_word, rabbit_info , rb):
        self.RabbitName = name
        self.RabbitWords = rabbit_word
        self.Rabbit_Dictionary = rabbit_info
        self.Mother = rb


    def Talk_Mother(self):
        self.Mother.say_greeting()
        print (Rabbit.Greeting)
        self.Mother.cook()
        self.say_angry_words()

    def say_words(self):
        print("Bunny : "+self.RabbitWords)

    def say_angry_words(self):
        print ("Bunny: 10 carrots ! No I fed up wiyh that")
        for i in range(0,3):
          print ("Bunny : I Don't Like Carrots and Lettuce")
        print ("Bunny : I am Leaving to find something else")

    def move_step(self):
        X = raw_input()

    def talk_animal(self, animal):
        print ("Bunny : Hi "+animal.Animal_Type + "  I am Hungry Give Me Food")
        animal.say_words()
        print ("Bunny : OK " + animal.Animal_Type + " I will try")

    def jump(self, number_of_jumps):
        # ToDo: Write method body

    @staticmethod
    def calculate_sqrt(num):
        print ("Bunny : "+ str(math.sqrt(num)))
        return math.sqrt(num)

    @staticmethod
    def find_string(my_string):
        if("Up" in my_string):
            print ("Bunny : Yes")
            return "yes"
        else:
            print ("Bunny : No")
            return "no"

    @staticmethod
    def matrix_opertaions(matrix, operand):
        result = [[0, 0], [0, 0], [0, 0]]
        for i in range(0, len(matrix)):
            for j in range(0, len(matrix[0])):
                result[i][j] = 2 * matrix[i][j]
        print ("Bunny : " + ', '.join(str(x) for x in result))
        return result

    @staticmethod
    def calculate_factorial(num):
        result = 1
        for i in range(1, num + 1):
            result = result * i
        print ("Bunny : %s" % result)
        return result

    @staticmethod
    def sort_list(mylist):
        mylist.sort(None,None,True)
        print ("Bunny : "+','.join(map(str, mylist)))
        return mylist

    @staticmethod
    def distinct_animals(animal_list):
        # ToDo: Write method body

    @staticmethod
    def ApplyGroupOperations(List):
        Max = max(List)
        Min = min(List)
        Sum = sum(List)
        Avg = sum(List) / len(List)
        print ("Bunny : Max = "+str(Max)+" Min = "+str(Min)+" Avg = "+str(Avg)+" Sum = "+ str(Sum))
        return Max, Min, Avg, Sum

    @staticmethod
    def repeat_string(mystr):
        print ("Bunny : "+mystr * 3)
        return mystr * 3

    @staticmethod
    def get_length(mystr):
        print ("Bunny : " + str(len(mystr)))
        return len(mystr)

    @staticmethod
    def get_from_list(mylist):
        print ("Bunny : " + mylist[-7:])
        return  mylist[-7:]

    def answer_animals_questions(self, Animal):
        score = 0
        if Animal.Animal_Type == "Lion":
            for x in range(0, len(Animal.Animal_QuestionsAnswers)):
                print ("Lion : "+Animal.Animal_QuestionsAnswers[x].Question_message)
                if self.Rabbit_Dictionary.get(Animal.Animal_QuestionsAnswers[x].Question) is None:
                    print ("Bunny : I am do not know !!!!")
                    continue
                elif self.Rabbit_Dictionary[Animal.Animal_QuestionsAnswers[x].Question] != Animal.Animal_QuestionsAnswers[x].Question_Answer:
                    print ("Bunny : I am Not Sure !!!!")
                    print ("Bunny : "+self.Rabbit_Dictionary[Animal.Animal_QuestionsAnswers[x].Question])
                else:
                    score = score + 1
                    print ("Bunny :" + self.Rabbit_Dictionary[Animal.Animal_QuestionsAnswers[x].Question])
            return score
        elif Animal.Animal_Type == "Monkey":
            # Ques 1
            print ("Monkey : " + Animal.Animal_QuestionsAnswers[0].Question_message)
            result = self.matrix_opertaions(Animal.Animal_QuestionsAnswers[0].Question, 2)
            for i in range(0, len(Animal.Animal_QuestionsAnswers[0].Question_Answer)):
                for j in range(0, len(Animal.Animal_QuestionsAnswers[0].Question_Answer[0])):
                    if result[i][j] == Animal.Animal_QuestionsAnswers[0].Question_Answer[i][j]:
                        score = score + 1
            # Ques 2
            print ("Monkey : " + Animal.Animal_QuestionsAnswers[1].Question_message)
            (Max, Min,Avg ,Sum) = self.ApplyGroupOperations(Animal.Animal_QuestionsAnswers[1].Question)
            if Max == Animal.Animal_QuestionsAnswers[1].Question_Answer[0] and Min == Animal.Animal_QuestionsAnswers[1].Question_Answer[1] and Avg == Animal.Animal_QuestionsAnswers[1].Question_Answer[2] and Sum == Animal.Animal_QuestionsAnswers[1].Question_Answer[3]:
                        score = score + 1
            return score

        elif Animal.Animal_Type == "Fox":
            # Ques1
            print ("Fox : " + Animal.Animal_QuestionsAnswers[0].Question_message)
            num1 = self.calculate_sqrt(Animal.Animal_QuestionsAnswers[0].Question)
            if num1 == Animal.Animal_QuestionsAnswers[0].Question_Answer:
                score = score + 1
            # Ques2
            print ("Fox : " + Animal.Animal_QuestionsAnswers[1].Question_message)
            self.sort_list(Animal.Animal_QuestionsAnswers[1].Question)
            for i in range(0, len(Animal.Animal_QuestionsAnswers[1].Question_Answer)):
                if Animal.Animal_QuestionsAnswers[1].Question == Animal.Animal_QuestionsAnswers[1].Question_Answer:
                    score = score + 1
            # Ques 3
            print ("Fox : " + Animal.Animal_QuestionsAnswers[2].Question_message)
            my_str1 = self.repeat_string(Animal.Animal_QuestionsAnswers[2].Question)
            if my_str1 == Animal.Animal_QuestionsAnswers[2].Question_Answer:
                score = score + 1
            # Ques 4
            print ("Fox : " + Animal.Animal_QuestionsAnswers[3].Question_message)
            num2 = self.calculate_factorial(Animal.Animal_QuestionsAnswers[3].Question)
            if num2 == Animal.Animal_QuestionsAnswers[3].Question_Answer:
                score = score + 1
            return score
        elif Animal.Animal_Type == "Cat":
            # Ques 1
            print ("Cat : "+Animal.Animal_QuestionsAnswers[0].Question_message)
            my_str2 = self.get_from_list(Animal.Animal_QuestionsAnswers[0].Question)
            if my_str2 == Animal.Animal_QuestionsAnswers[0].Question_Answer:
                score = score + 1
             # Ques 2
            print ("Cat : " + Animal.Animal_QuestionsAnswers[1].Question_message)
            my_str2 = self.find_string(Animal.Animal_QuestionsAnswers[1].Question)
            if my_str2 == Animal.Animal_QuestionsAnswers[1].Question_Answer:
                score = score + 1
            # Ques 3
            print ("Cat : " + Animal.Animal_QuestionsAnswers[2].Question_message)
            my_str4 = self.get_length(Animal.Animal_QuestionsAnswers[2].Question)
            if my_str4 == Animal.Animal_QuestionsAnswers[2].Question_Answer:
                score = score + 1
            return score
        elif Animal.Animal_Type == "Dog":
            #Todo: Write Scenario to answer dog questions
            # Ques 1


            # Ques 2

