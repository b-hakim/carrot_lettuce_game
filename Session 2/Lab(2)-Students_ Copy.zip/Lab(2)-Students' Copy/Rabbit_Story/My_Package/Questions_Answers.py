class QuestionsAnswers:

    def __init__(self, q_msg,question, answer):
        self.Question_message = q_msg
        self.Question = question
        self.Question_Answer = answer

