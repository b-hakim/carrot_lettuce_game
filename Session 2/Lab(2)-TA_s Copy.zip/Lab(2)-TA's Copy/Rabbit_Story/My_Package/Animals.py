class Animal:
    def __init__(self, a_type,a_name,a_words,a_questions_answers,score ):
        self.Animal_Type = a_type
        self.Animal_Name = a_name
        self.Animal_Words = a_words
        self.Animal_QuestionsAnswers = a_questions_answers
        self.score = score

    def say_words(self):
        print(self.Animal_Type+ " : "+self.Animal_Words)
        print(self.Animal_Type + " : " + "Ok First Answer My Question")
